/*#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
#include<time.h>
#include<conio.h>
#define BOARD_SIZE 6
#define TRUE 0
#define FALSE 1
struct name {
	char name[40];
	int id;
	int age;
}s;
FILE *fp;
char board[BOARD_SIZE][BOARD_SIZE];
char game_board[BOARD_SIZE][BOARD_SIZE];
int lost = 0;
void display_welcome();
void build_board();
void intro(struct name s);
void build_gboard();
void create_mines();
void print_board();
void print_fullboard();
void start();
int play_game();
void play_again();
int check_win_game();
void check_for_mine(int, int);
int check_for_nearby_mines(int, int);
int main(){
    char b;
	display_welcome();
    intro(s);
    fp=fopen("Game.txt","r+");
    if(fp==NULL){
    	printf("ERROR !!\n");
    	exit(0);
	}
	fscanf(fp,"%s",s.name);
    printf("Lets Play :  %s \n",s.name);
    printf("\nWhen you're ready... Just press (a) . :)\n");
    b=getch();
    if(b==97){
	system("cls");
    start();
    return 0;
	}
	else{
		printf("Sorry You Typed Wrong Button \n");
		printf("Press Shortcut Button (b) to start from here \n");
		b=getch();
		if(b==98){
		system("cls");	
		start();
		}
	}
}
void intro(struct name s){
 	printf("Enter Player Name : \n");
 	gets(s.name);
 	printf("Enter Your ID :\n");
 	scanf("%d",&s.id);
 	printf("Please Enter Your Age :\n");
 	scanf("%d",&s.age);
    fp=fopen("Game.txt","w+");
    if(fp==NULL){
    printf("ERROR !!\n");
    exit(0);
	}
	if(s.age>7){
    fprintf(fp,"%s    %d   %d",s.name,s.id,s.age);
    fclose(fp);
    }
    else{
    	printf("Sorry You are not applicable for this Game \n");
    	printf("Have a good Day !!\n");
    	exit(0);
	}
 }
void build_board(){
    int i, j;
    for(i=0;i<BOARD_SIZE;i++)
        for(j=0;j<BOARD_SIZE;j++)
            board[i][j]='o';
    create_mines();
}
void build_gboard(){
    int i,j;
    int row,col;
    printf("Creating game board....\nReady..set..\nPLAY!\n\n");
    for(i=0;i<BOARD_SIZE;i++)
        for(j=0;j<BOARD_SIZE;j++)
            game_board[i][j]='o';
    for(col=0;col<BOARD_SIZE;col++)
        printf("%d ",col+1);
    printf("\n\n");
    for(row=0;row<BOARD_SIZE;row++){
        for(col=0;col<BOARD_SIZE;col++){
            printf("%c ",game_board[row][col]);
        }
        printf(" %d ",row+1);
        printf("\n");
    }
}
void create_mines(){
    int i,random;
    srand(time(0));
    for (i=0;i<BOARD_SIZE;i++){
        random=rand()%(BOARD_SIZE);
        board[random][i]='*';
    }
}
void print_board(){
    int row,col;
    system("cls");
    for(col=0;col<BOARD_SIZE;col++)
    printf("%d ",col+1);
    printf("\n\n");
    for(row=0;row<BOARD_SIZE;row++){
        for(col=0;col<BOARD_SIZE;col++){
            printf("%c ",game_board[row][col]);
        }
        printf(" %d ",row+1);
        printf("\n");
    }
}
void print_fullboard(){
    int row,col;
    system("cls");
    for(col=0;col<BOARD_SIZE;col++)
    printf("%d ",col+1);
    printf("\n\n");
    for(row=0;row<BOARD_SIZE;row++){
        for(col=0;col<BOARD_SIZE;col++){
            printf("%c ",board[row][col]);
        }
        printf(" %d ",row+1);
        printf("\n");
    }
}
int play_game(){
    int r_selection=0,c_selection=0, 
        nearbymines=0,nearbymines2=0,
        nearbymines3=0,nearbymines4=0,
        nearbymines5=0,nearbymines6=0,
        nearbymines7=0,nearbymines8=0,
        i=0;
     char b;
    fp=fopen("Game.txt","a");
    if(fp==NULL)
    exit(0);
    do{	
    printf("\nMake a selection (ie. row [ENTER] col): \n");
    printf("Row--> ");
	scanf("%d", &r_selection);
    printf("Col--> ");
    scanf("%d", &c_selection); 
    } while(r_selection < 1 || r_selection > BOARD_SIZE || c_selection < 1 || r_selection > BOARD_SIZE);
    check_for_mine(r_selection-1,c_selection-1);
    if(lost==1)
        return -1;
    nearbymines=check_for_nearby_mines(r_selection-1,c_selection-1);
    game_board[r_selection-1][c_selection-1]=(char)(((int)'0')+nearbymines);
    if(nearbymines==0){
        if(c_selection!=BOARD_SIZE){
            i=0;
            while(nearbymines==0 && (c_selection-1+i)<BOARD_SIZE){
                nearbymines=check_for_nearby_mines(r_selection-1,(c_selection-1+i));
                if(nearbymines!=-1){
                game_board[r_selection-1][(c_selection-1)+i]=(char)(((int)'0')+nearbymines);
                i++;
                }
            }
            if(r_selection!=1){
                i=0;
                while(nearbymines5==0 && (c_selection-1+i)<BOARD_SIZE && (r_selection-1-i)>0){
                          nearbymines5=check_for_nearby_mines((r_selection-1-i),(c_selection-1+i));
                        if(nearbymines5!=-1){
                        game_board[(r_selection-1)-i][(c_selection-1)+i]=(char)(((int)'0')+nearbymines5);
                        i++;
                        }
                    }
                }
                if(r_selection != BOARD_SIZE){
                    i=0;
                    while(nearbymines6==0 && (r_selection-1+i)<BOARD_SIZE && (c_selection-1+i)<BOARD_SIZE ){
                        nearbymines6=check_for_nearby_mines((r_selection-1+i),(c_selection-1+i));
                        if(nearbymines!=-1){
                        game_board[(r_selection-1)+i][(c_selection-1)+i]=(char)(((int)'0')+nearbymines6);
                        i++;
                        }
                    }
                }
        }
        if(r_selection!=BOARD_SIZE){
            i=0;
            while(nearbymines2==0 && (r_selection-1+i)<BOARD_SIZE){
                nearbymines2=check_for_nearby_mines((r_selection-1+i),c_selection-1);
                if(nearbymines2!=-1){
                game_board[(r_selection-1)+i][c_selection-1]=(char)(((int)'0')+nearbymines2);
                i++;
                }
            }
            if(c_selection!=BOARD_SIZE){
                i=0;
                while(nearbymines7==0 && (r_selection-1+i)<BOARD_SIZE && (c_selection-1-i)>0){
                    nearbymines7=check_for_nearby_mines((r_selection-1+i),(c_selection-1-i));
                    if(nearbymines!=-1){
                    game_board[(r_selection-1)+i][(c_selection-1)-i]=(char)(((int)'0')+nearbymines7);
                    i++;
                    }
                }
            }
        }
        if(r_selection!= 1){
            i=0;
            while(nearbymines3==0 && (r_selection-i)>0){
                nearbymines3=check_for_nearby_mines((r_selection-1-i),c_selection-1);
                if(nearbymines3!=-1){
                game_board[(r_selection-1)-i][c_selection-1]=(char)(((int)'0')+nearbymines3);
                i++;
                }
            }
            if(c_selection!=BOARD_SIZE){
                while(nearbymines8==0 && (c_selection-1-i)>0 && (r_selection-1-i)>0){
                    nearbymines8=check_for_nearby_mines((r_selection-1-i),(c_selection-1-i));
                    if(nearbymines8!=-1){
                    game_board[(r_selection-1)-i][(c_selection-1)-i]=(char)(((int)'0')+nearbymines8);
                    i++;
                    }
                }    
            }
        }
        if(c_selection!=1){
            i=0;
            while(nearbymines4==0 && (c_selection-i)>0){
                nearbymines4=check_for_nearby_mines(r_selection-1,(c_selection-1-i));
                if(nearbymines4!=-1){
                game_board[r_selection-1][(c_selection-1)-i]=(char)(((int)'0')+nearbymines4);
                i++;
                }
            }
        }
    }
    if(check_win_game()==TRUE){
        system("cls");
        print_fullboard();
        fputs("\nPerivious Game : Won \n",fp);
        printf("\n\nYou've won the game!! Congrats!!\n\n");
        play_again();
    }
    fclose(fp); 
    return 0;
}
void check_for_mine(int r_select,int c_select){
	fp=fopen("Game.txt","a");
    if(fp==NULL)
    exit(0);
    if(board[r_select][c_select]=='*'){
    	 fputs("\nPerivious Game : Lose \n",fp);
        printf("\nYou've hit a mine! You lose!\n");
        getchar(); getchar();
        lost = 1;
    }
    fclose(fp);
}
int check_for_nearby_mines(int r_select,int c_select){
    int nearby_mine_count=0;
    if(board[r_select][c_select]=='*'){
        return -1;
    }
    if(r_select<(BOARD_SIZE-1) && c_select<(BOARD_SIZE-1)){
        if(board[r_select+1][c_select]=='*')
            nearby_mine_count++;
        if(board[r_select][c_select+1]=='*')
            nearby_mine_count++;
        if(board[r_select+1][c_select+1]=='*')
            nearby_mine_count++;
        if(c_select!=0){
            if(board[r_select+1][c_select-1]=='*')
                nearby_mine_count++;
            if(board[r_select][c_select-1]=='*')
                nearby_mine_count++;
        }
        if(r_select!= 0){
            if(board[r_select-1][c_select]=='*')
                nearby_mine_count++;
            if(board[r_select-1][c_select+1]=='*')
                nearby_mine_count++;
            if(c_select!=0){
                if(board[r_select-1][c_select-1]=='*')
                    nearby_mine_count++;
            }
        }
    }
    if(r_select==(BOARD_SIZE-1) && c_select!=(BOARD_SIZE-1)){
            if(board[r_select-1][c_select]=='*')
                nearby_mine_count++;
            if(board[r_select-1][c_select+1]=='*')
                nearby_mine_count++;
    }
    if(c_select==(BOARD_SIZE-1) && r_select!=(BOARD_SIZE-1)){
            if(board[r_select][c_select-1]=='*')
                nearby_mine_count++;
                if(board[r_select + 1][c_select - 1] == '*')
                nearby_mine_count++;
    }
    if(r_select==(BOARD_SIZE-1) && c_select==(BOARD_SIZE-1)){
            if(board[r_select][c_select-1]=='*')
                nearby_mine_count++;
            if(board[r_select-1][c_select-1]=='*')
                nearby_mine_count++;
            if(board[r_select-1][c_select]=='*')
                nearby_mine_count++;
    }
    return nearby_mine_count;
}
int check_win_game(){
    int row,col;
    for(row=0;row<BOARD_SIZE;row++)
        for(col=0;col<BOARD_SIZE;col++){
            if(game_board[row][col]=='o' && board[row][col]!='*')
                return FALSE;
        }
    return TRUE;
}
void play_again(){
    char ans;
    printf("\n\nWould you like to play again? (y/n) --> ");
    scanf(" %c",&ans); 
    if(toupper(ans)=='Y'){
        system("cls");
        start();
    } 
    else{
        printf("\n\nThanks for playing! %s Bye.\n",s.name);
        (void) getchar();
        exit(EXIT_SUCCESS);
    }
}
void display_welcome(){
    puts("-----------------------Welcome to Minesweeper!---------------------------");
    puts("\n\n");
}
void start(){
    lost=0;
    build_board();
    build_gboard();
    do{
    play_game();
    print_board();
    } 
	while(lost!= 1);
    print_fullboard();
    play_again();
}
*/
//##########TIC TAC TOE#########################//
#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<string.h>
#include<Windows.h>    
#include<unistd.h>
#include<time.h>
char user1[50],user2[50];
int balance1,balance2;
struct date{
	int day;
	int month;
	int year;
};
struct userInfo{
	char fullName[50];
	char userName[30];
	char password[30];
	int balance;
	struct date dob;
};
struct admin{
	char userN[50];
	char pass[30];
};
void displayInfo(char userN[30]);
void registration();
void ticTacToe();
void login(int opt);
void displayMenu();
void addFund(char userName[50],int fund);
void removeFund(char userName[50], int fund);
int currentBalance(char userName[50]);
void login1();
void login2();
void gameMenu();
void deleteUser(char userName[30]);
void loginAdmin();
void adminMenu();
void viewUsers();
void viewHistory();
void main(void){
	displayMenu();
}
void registration(){
	fflush(stdin);
	struct userInfo user;
	char passM[30];
	int i=0,j;
	int bFlag=0,bFlag2=0;
	FILE *fp=fopen("data.txt","a");
	FILE *fp2=fopen("data.txt","r");
	struct userInfo tempU;
	char ch;
	
	system("CLS");
	system("COLOR 0C");
	
	while(1){	
	printf("------------------Registration------------------\n");
	fflush(stdin);
	while(1){
		printf("Enter Full Name: ");gets(user.fullName);fflush(stdin);
		printf("Enter UserName: ");gets(user.userName);fflush(stdin);
		if(strcmp("",user.fullName)==0 || strcmp("",user.userName)==0){
			printf("\nRegistration Fields Cannot Be blank..\n");
			printf("Press Any key To Start Registration Again...\nPress Backspace to Go Back To Main Menu\n");
			ch=getch();
			if(ch=='\b'){
				displayMenu();
				break;
			}
			else{
				registration();
				break;
			}
		}
		else{
			break;
		}
	}
	
		while(fread(&tempU,sizeof(tempU),1,fp2)>0){
		if(strcmp(tempU.userName,user.userName)==0){
			printf("User Already exists...\n");
			printf("Press Any key To Start Registration Again...\nPress Backspace to Go Back To Main Menu\n");
			ch=getch();
			if(ch=='\b'){
				displayMenu();
				break;
			}
			else{
				registration();
				break;
			}
		}
	}
	while(1){
		i=0;
		system("CLS");
		printf("Password: ");
	while(1){
		user.password[i]=getch();
		if(user.password[0]=='\r'){
			printf("\nPassword cannot be blank..\n");
			printf("Press Any key To Start Registration Again...\nPress Backspace to Go Back To Main Menu\n");
			ch=getch();
			if(ch=='\b'){
				displayMenu();
				break;
			}
			else{
				registration();
				break;
			}
		}
		else{
		if(user.password[i]=='\r'){
			break;
		}
		else if(user.password[i]=='\b'){
			user.password[i]='\0';
			bFlag2=1;
			system("CLS");printf("Password: ");
			if(i>0){
				i--;
			}
			
			for(j=1;j<=i;j++){
				printf("*");	
			}
		}
		else{
			printf("*");
			i++;
		}
	}
		
	}
		int len2;
		len2=strlen(user.password);
		user.password[len2-1]='\0';
		i=0;
	
		system("CLS");
		printf("Enter Password Again: ");
	while(1){
		passM[i]=getch();
		if(passM[i]=='\r'){
			break;
		}
		else if(passM[i]=='\b'){
			passM[i]='\0';
			bFlag=1;
			system("CLS");printf("Enter Password Again: ");
			if(i>0){
				i--;
			}
			for(j=1;j<=i;j++){
				printf("*");	
			}
		}
		else{
			printf("*");
			i++;
		}
	}
	int len;
		len=strlen(passM);
		passM[len-1]='\0';
		if(strcmp(user.password,passM)==0){
			break;
		}
		else{
			printf("Passwords Not Matched..\n\n");
		}
	}
	while(1){
		printf("\nEnter day of birth(1-31): ");scanf("%d",&user.dob.day);
		printf("Enter month of birth(1-12): ");scanf("%d",&user.dob.month);
		printf("Enter Year of birth(19xx-20xx): ");scanf("%d",&user.dob.year);
		if(user.dob.day<1 || user.dob.day>31 || user.dob.month<1 || user.dob.month>12 || user.dob.year>2019 || user.dob.year<1900){
			printf("\nInvalid Birth Info...Kindly Follow the pattern mentioned above..\n");
			printf("Press Backspace to Go to Menu or Press any key to continue: ");ch=getch();
					if(ch=='\b'){
						displayMenu();
						break;
					}
					else{
						system("CLS");
						fflush(stdin);
					}
		}
		else{
			break;
		}
	}
	if(2019-user.dob.year>=18){
		while(1){
			printf("Enter Starting Balance: ");scanf("%d",&user.balance);
			if(user.balance<0){
				printf("Balance Cannot Be negative...\n");
			}
			else{
				break;
			}		
		}
		printf("\nRegistration Successfull...\n");
		printf("Heading Back to Menu in 3 seconds...\n");sleep(3);
		fwrite(&user,sizeof(user),1,fp);
		fclose(fp);
		displayMenu();
		break;
	}
	else{
		system("CLS");
		printf("\nYou are not old enough to start betting.....\n");
		printf("Heading Back to Menu in 3 seconds...\n");sleep(3);
		displayMenu();
	}
}	
}
void displayInfo(char userN[30]){
	fflush(stdin);
	FILE *fp=fopen("data.txt","r");
	struct userInfo user;
	while(fread(&user,sizeof(user),1,fp)>0){
		if(strcmp(user.userName,userN)==0){
			printf("--------------Player Information--------------\n\n");
			printf("Full Name: ");puts(user.fullName);
			printf("UserName: ");puts(user.userName);
			printf("DOB: %d/%d/%d",user.dob.day,user.dob.month,user.dob.year);
			printf("\nCurrent Balance: %d",user.balance);
		}
	}
	fclose(fp);
}
void ticTacToe(){
	fflush(stdin);
	int x=1,win=0,count=0;
	char choice[5];
	char sym[9]={' ',' ',' ',' ',' ',' ',' ',' ',' '};
	int bet;
	char ch,ch1;
	FILE *fp2=fopen("history.txt","a");
	while(1){
	balance1=currentBalance(user1);
	balance2=currentBalance(user2);
	
	printf("\nEnter Betting Amount(1-10000): ");scanf("%d",&bet);
	if(bet>0 && bet<=10000){
		break;
	}
	else{
		printf("\nInvalid Betting Amount...\n");
		printf("Press Backspace To Head to Game Menu\nPress Any Other Key To Continue...");ch1=getch();
		if(ch1=='\b'){
				gameMenu();
				break;
			}
			else{
				system("CLS");
				ticTacToe();
				break;
			}
	}
	if(balance1<bet){
		printf("\n%s has insufficient balance...",user1);
		printf("Press Backspace To Head to Game Menu\nPress Any Other Key To Continue...");ch1=getch();
			if(ch1=='\b'){
				gameMenu();
				break;
			}
			else{
				system("CLS");
				ticTacToe;
				break;
			}
	}
	else if(balance2<bet){
		printf("\n%s has insufficient balance...",user2);
		printf("Press Backspace To Head to Game Menu\nPress Any Other Key To Continue...");ch1=getch();
			if(ch1=='\b'){
				gameMenu();
				break;
			}
			else{
				system("CLS");
				ticTacToe();
				break;
			}
	}
	else{
		break;
	}
}
	while(1)
	{
	
    printf("\t\t\t\tT i c	t a c	t o e");printf("\n%s\'s Symbol: O",user1);printf("\n%s\'s 2 Symbol: X",user2);printf("\n\t\t\t       |       |       ");printf("\n\t\t\t   %c   |   %c   |   %c   ",sym[0],sym[1],sym[2]);printf("\n\t\t\t-------|-------|-------");printf("\n\t\t\t   %c   |   %c   |   %c   ",sym[3],sym[4],sym[5]);printf("\n\t\t\t-------|-------|-------");printf("\n\t\t\t   %c   |   %c   |   %c   ",sym[6],sym[7],sym[8]);printf("\n\t\t\t       |       |       ");
	    if(x==1)
	    printf("\n%s\'s turn\n\nEnter Position : ",user1);
		else if(x==2)
		printf("\n%s\'s turn\n\nEnter Position : ",user2);
		gets(choice);
		system("CLS");
		if(x==1)x=2;else{x=1;}
		if(strlen(choice)!=1) 
		{
		printf("Please Select A Valid Position.\n\n");
		if(x==1)x=2;else x=1;
		continue;
	    }else if(!(choice[0]>='1'&&choice[0]<='9'))
		{
	    printf("Please Select A Valid Position.\n\n");
		if(x==1)x=2;else x=1;
		continue;	
		}
		if(choice[0]=='1')
		{
		if(sym[0]=='X'||sym[0]=='O')
		{
			printf("Invalid Choice.");
			if(x==1)x=2;else x=1;
			continue;
		}
		else if(x%2==0)
		{
		sym[0]='O';
	    count++;
		}
		else
		{
		sym[0]='X';
     	count++;
		}
	    }else if(choice[0]=='2')
		{
		if(sym[1]=='X'||sym[1]=='O')
		{
			printf("Invalid Choice.");
			if(x==1)x=2;else x=1;
			continue;
		}
		else if(x%2==0)
		{
		sym[1]='O';
	    count++;
		}
		else
		{
		sym[1]='X';
     	count++;
		}
	    }
		else if(choice[0]=='3')
		{
		if(sym[2]=='X'||sym[2]=='O')
		{
			printf("Invalid Choice.");
			if(x==1)x=2;else x=1;
			continue;
		}
		else if(x%2==0)
		{
		sym[2]='O';
	    count++;
		}
		else
		{
		sym[2]='X';
     	count++;
		}
		}else if(choice[0]=='4')
		{
		if(sym[3]=='X'||sym[3]=='O')
		{
			printf("Invalid Choice.");
			if(x==1)x=2;else x=1;
			continue;
		}
		else if(x%2==0)
		{
		sym[3]='O';
	    count++;
		}
		else
		{
		sym[3]='X';
    	count++;
		}
		}else if(choice[0]=='5')
		{
		if(sym[4]=='X'||sym[4]=='O')
		{
			printf("Invalid Choice.");
						if(x==1)x=2;else x=1;
			continue;
		}
		else if(x%2==0)
		{
		sym[4]='O';
	    count++;
		}
		else
		{
		sym[4]='X';
     	count++;
		}
		}else if(choice[0]=='6')
		{
		if(sym[5]=='X'||sym[5]=='O')
		{
			printf("Invalid Choice.");
			if(x==1)x=2;else x=1;
			continue;
		}
		else if(x%2==0)
		{
		sym[5]='O';
	    count++;
		}
		else
		{
		sym[5]='X';
     	count++;
		}
		}else if(choice[0]=='7')
		{
		if(sym[6]=='X'||sym[6]=='O')
		{
			printf("Invalid Choice.");
			if(x==1)x=2;else x=1;
			continue;
		}
		else if(x%2==0)
		{
		sym[6]='O';
	    count++;
		}
		else
		{
		sym[6]='X';
     	count++;
		}
		}else if(choice[0]=='8')
		{
		if(sym[7]=='X'||sym[7]=='O')
		{
			printf("Invalid Choice.");
			if(x==1)x=2;else x=1;
			continue;
		}
		else if(x%2==0)
		{
		sym[7]='O';
	    count++;
		}
		else
		{
		sym[7]='X';
     	count++;
		}
		}else if(choice[0]=='9')
		{
		if(sym[8]=='X'||sym[8]=='O')
		{
			printf("Invalid Choice.");
			if(x==1)x=2;else x=1;
			continue;
		}
		else if(x%2==0)
		{
		sym[8]='O';
	    count++;
		}
		else
		{
		sym[8]='X';
     	count++;
		}
        }

if((sym[0]=='O'&&sym[1]=='O'&&sym[2]=='O')||(sym[3]=='O'&&sym[4]=='O'&&sym[5]=='O')||(sym[6]=='O'&&sym[7]=='O'&&sym[8]=='O')||(sym[2]=='O'&&sym[5]=='O'&&sym[8]=='O')||(sym[1]=='O'&&sym[4]=='O'&&sym[7]=='O')||(sym[0]=='O'&&sym[3]=='O'&&sym[6]=='O')||(sym[0]=='O'&&sym[4]=='O'&&sym[8]=='O')||(sym[2]=='O'&&sym[4]=='O'&&sym[6]=='O'))
{
	printf("\t\t\t\tT i c	t a c	t o e");printf("\n%s\'s Symbol: O",user1);printf("\n%s\'s 2 Symbol: X",user2);printf("\n\t\t\t       |       |       ");printf("\n\t\t\t   %c   |   %c   |   %c   ",sym[0],sym[1],sym[2]);printf("\n\t\t\t-------|-------|-------");printf("\n\t\t\t   %c   |   %c   |   %c   ",sym[3],sym[4],sym[5]);printf("\n\t\t\t-------|-------|-------");printf("\n\t\t\t   %c   |   %c   |   %c   ",sym[6],sym[7],sym[8]);printf("\n\t\t\t       |       |       ");
	printf("\n%s is the winner!",user1);
	addFund(user1,bet);
	removeFund(user2,bet);
	printf("\n%s\'s Current Balance %d\n\n",user1,currentBalance(user1));
	printf("\n%s\'s Current Balance %d\n\n",user2,currentBalance(user2));
	fprintf(fp2,"\n%s won %d ",user1,bet);
	fprintf(fp2,"\n%s lost %d \n",user2,bet);
	fclose(fp2);
	printf("Press Backspace To Head to Game Menu\nPress Any Other Key To Continue...");ch=getch();
	if(ch=='\b'){
		gameMenu();
	}
	else{
		system("CLS");
		ticTacToe();
	}
	break;
}else if((sym[0]=='X'&&sym[1]=='X'&&sym[2]=='X')||(sym[3]=='X'&&sym[4]=='X'&&sym[5]=='X')||(sym[6]=='X'&&sym[7]=='X'&&sym[8]=='X')||(sym[2]=='X'&&sym[5]=='X'&&sym[8]=='X')||(sym[1]=='X'&&sym[4]=='X'&&sym[7]=='X')||(sym[0]=='X'&&sym[3]=='X'&&sym[6]=='X')||(sym[0]=='X'&&sym[4]=='X'&&sym[8]=='X')||(sym[2]=='X'&&sym[4]=='X'&&sym[6]=='X'))
{
	printf("\t\t\t\tT i c	t a c	t o e");printf("\n%s\'s Symbol: O",user1);printf("\n%s\'s 2 Symbol: X",user2);printf("\n\t\t\t       |       |       ");printf("\n\t\t\t   %c   |   %c   |   %c   ",sym[0],sym[1],sym[2]);printf("\n\t\t\t-------|-------|-------");printf("\n\t\t\t   %c   |   %c   |   %c   ",sym[3],sym[4],sym[5]);printf("\n\t\t\t-------|-------|-------");printf("\n\t\t\t   %c   |   %c   |   %c   ",sym[6],sym[7],sym[8]);printf("\n\t\t\t       |       |       ");
	printf("\n%s is the winner!",user2);
	addFund(user2,bet);
	removeFund(user1,bet);
	printf("\n%s\'s Current Balance %d\n\n",user1,currentBalance(user1));
	printf("\n%s\'s Current Balance %d\n\n",user2,currentBalance(user2));
	fprintf(fp2,"\n%s won %d ",user2,bet);
	fprintf(fp2,"\n%s lost %d\n",user1,bet);
	fclose(fp2);
	printf("Press Backspace To Head to Game Menu\nPress Any Other Key To Continue...");ch=getch();
	if(ch=='\b'){
		gameMenu();
	}
	else{
		system("CLS");
		ticTacToe();
	}
	break;
}else if(count==9){
printf("\t\t\t\tT i c	t a c	t o e");printf("\n%s\'s Symbol: O",user1);printf("\n%s\'s 2 Symbol: X",user2);printf("\n\t\t\t       |       |       ");printf("\n\t\t\t   %c   |   %c   |   %c   ",sym[0],sym[1],sym[2]);printf("\n\t\t\t-------|-------|-------");printf("\n\t\t\t   %c   |   %c   |   %c   ",sym[3],sym[4],sym[5]);printf("\n\t\t\t-------|-------|-------");printf("\n\t\t\t   %c   |   %c   |   %c   ",sym[6],sym[7],sym[8]);printf("\n\t\t\t       |       |       ");
printf("\nThe Match is draw.");
printf("\n%s\'s Current Balance %d\n\n",user1,currentBalance(user1));
	fprintf(fp2,"\n%s and %s tied for %d\n",user1,user2,bet);
	fclose(fp2);
	printf("\n%s\'s Current Balance %d\n\n",user2,currentBalance(user2));
	printf("Press Backspace To Head to Game Menu\nPress Any Other Key To Continue...");ch=getch();
	if(ch=='\b'){
		gameMenu();
	}
	else{
		system("CLS");
		ticTacToe();
	}
break;
}
} 
}
void login(int opt){
	fflush(stdin);
	system("CLS");
	char userEntered[50];
	char passEntered[50];
	int flag=0;
	char ch;
	int balance;
	int currentBalance;
	int i=0,j;
	printf("\n------------------------Player Login------------------------\n");
	FILE *fp=fopen("data.txt","r");
	struct userInfo user;
	while(1){
		fflush(stdin);
		i=0;
		printf("Enter Username: ");gets(userEntered);fflush(stdin);
		system("CLS");
		printf("Password: ");
	while(1){
		passEntered[i]=getch();
		if(passEntered[i]=='\r'){
			break;
		}
		else if(passEntered[i]=='\b'){
			passEntered[i]='\0';
			system("CLS");printf("Password: ");
			i--;
			for(j=1;j<=i;j++){
				printf("*");	
			}
		}
		else{
			printf("*");
			i++;
		}
		
	}
	int len;
	len=strlen(passEntered);
	passEntered[len-1]='\0';
		while(fread(&user,sizeof(user),1,fp)>0){
			if(strcmp(user.userName,userEntered)==0 && strcmp(user.password,passEntered)==0){
				printf("\nWelcome ");puts(user.fullName);
				displayInfo(userEntered);
				flag=1;
				currentBalance=user.balance;
				break;
			}
			
		}
		if(flag==1){
			if(opt==2){
				system("CLS");
				displayInfo(userEntered);
				printf("\n\nEnter Balance You Want to Add: ");scanf("%d",&balance);
				if(balance<0){
					printf("\nAmount cannot be negative....\n\n");
					printf("Press Backspace to Go to Menu or Press any key to continue: ");ch=getch();
					if(ch=='\b'){
					displayMenu();
					}
					else{
						login(opt);	
					}
					}
				addFund(userEntered,balance);
				printf("Balance successfully added...\n");
				printf("New balance is: %d\n",balance+currentBalance);
				printf("\nHeading Back to Menu in 4 seconds...\n");sleep(4);
				displayMenu();
				
			}
			else if(opt==3){
				system("CLS");
				displayInfo(userEntered);
				printf("\n\nEnter How Much You want to withdraw: ");scanf("%d",&balance);
				if(balance<0){
					printf("\nAmount cannot be negative....\n\n");
					printf("Press Backspace to Go to Menu or Press any key to continue: ");ch=getch();
					if(ch=='\b'){
					displayMenu();
					}
					else{
						login(opt);	
					}
					}
				if(currentBalance<balance){
					printf("Insufficient Funds...\n");
					printf("Your Current Balance is: %d\n",currentBalance);
					printf("Press Backspace to Go to Menu or Press any key to continue: ");ch=getch();
					if(ch=='\b'){
					displayMenu();
					}
					else{
						login(opt);	
					}
				}
				else{
					removeFund(userEntered,balance);
					printf("Balance successfully withdrawed...\n");
					printf("New balance is: %d\n",currentBalance-balance);
					printf("Press Backspace to Go to Menu or Press any key to continue: ");ch=getch();
					if(ch=='\b'){
						displayMenu();
					}
					else{
						login(opt);	
					}
					
				}
				
			}
			break;
		}
		else{
		    printf("\nUserName Or Password Not Matched....\n");
			printf("Press Backspace to Go to Menu or Press any key to continue: ");ch=getch();
			if(ch=='\b'){
				displayMenu();
			}
			else{
				login(opt);	
			}
			
			break;
		}
		
		
	}
}
void addFund(char userN[50], int fund){
	fflush(stdin);
	struct userInfo tempUser;
	int userCount=0;
	FILE *fp=fopen("data.txt","r");
	FILE *clearF=fopen("temp.txt","w");
	fclose(clearF);
	FILE *tempF=fopen("temp.txt","a");
	

	while(fread(&tempUser,sizeof(tempUser),1,fp)>0){
		if(strcmp(userN,tempUser.userName)==0){
			tempUser.balance=tempUser.balance+fund;
		}
		fwrite(&tempUser,sizeof(tempUser),1,tempF);
	}
	
	fclose(fp);
	FILE *clearOrigF=fopen("data.txt","w");
	fclose(clearOrigF);
	FILE *origF=fopen("data.txt","a");
	fclose(tempF);
	FILE *tempF2=fopen("temp.txt","r");
	while(fread(&tempUser,sizeof(tempUser),1,tempF2)>0){
		fwrite(&tempUser,sizeof(tempUser),1,origF);
	}
	fclose(tempF2);
	fclose(origF);
}
void removeFund(char userN[50], int fund){
	fflush(stdin);
	struct userInfo tempUser;
	int userCount=0;
	FILE *fp=fopen("data.txt","r");
	FILE *clearF=fopen("temp.txt","w");
	fclose(clearF);
	FILE *tempF=fopen("temp.txt","a");


	while(fread(&tempUser,sizeof(tempUser),1,fp)>0){
		if(strcmp(userN,tempUser.userName)==0){
			tempUser.balance=tempUser.balance-fund;
		}
		fwrite(&tempUser,sizeof(tempUser),1,tempF);
	}
	
	fclose(fp);
	FILE *clearOrigF=fopen("data.txt","w");
	fclose(clearOrigF);
	FILE *origF=fopen("data.txt","a");
	fclose(tempF);
	FILE *tempF2=fopen("temp.txt","r");
	while(fread(&tempUser,sizeof(tempUser),1,tempF2)>0){
		fwrite(&tempUser,sizeof(tempUser),1,origF);
	}
	fclose(tempF2);
	fclose(origF);
}
int currentBalance(char userN[50]){
	fflush(stdin);
	FILE *fp=fopen("data.txt","r");
	struct userInfo user;
	while(fread(&user,sizeof(user),1,fp)>0){
		if(strcmp(user.userName,userN)==0){
			return user.balance;
		}
	}
	fclose(fp);
}
void displayMenu(){
	fflush(stdin);
	system("CLS");
	char ch;
	int count=0;
	
	while(ch!='\r' && ch!=77){
		
		if(count==0){
			printf("-----------Main Menu------------\n");
			printf("-> Login\n");
			printf("   Registration\n");
			printf("   Add Funds\n");
			printf("   Withdraw Funds\n");
			printf("   Admin Login\n");
			printf("   Exit\n");
			printf("--------------------------------\n");
		}
		
		if(count==1){
			printf("-----------Main Menu------------\n");
			printf("   Login\n");
			printf("-> Registration\n");
			printf("   Add Funds\n");
			printf("   Withdraw Funds\n");
			printf("   Admin Login\n");
			printf("   Exit\n");
			printf("--------------------------------\n");
		}
		
		if(count==2){
			printf("-----------Main Menu------------\n");
			printf("   Login\n");
			printf("   Registration\n");
			printf("-> Add Funds\n");
			printf("   Withdraw Funds\n");
			printf("   Admin Login\n");
			printf("   Exit\n");
			printf("--------------------------------\n");
		}
		
		if(count==3){
			printf("-----------Main Menu------------\n");
			printf("   Login\n");
			printf("   Registration\n");
			printf("   Add Funds\n");
			printf("-> Withdraw Funds\n");
			printf("   Admin Login\n");
			printf("   Exit\n");
			printf("--------------------------------\n");
		}
		
		if(count==4){
			printf("-----------Main Menu------------\n");
			printf("   Login\n");
			printf("   Registration\n");
			printf("   Add Funds\n");
			printf("   Withdraw Funds\n");
			printf("-> Admin Login\n");
			printf("   Exit\n");
			printf("--------------------------------\n");
		}
		if(count==5){
			printf("-----------Main Menu------------\n");
			printf("   Login\n");
			printf("   Registration\n");
			printf("   Add Funds\n");
			printf("   Withdraw Funds\n");
			printf("   Admin Login\n");
			printf("-> Exit\n");
			printf("--------------------------------\n");
		}
		ch=getch();
		system("CLS");
		if(ch==72){
			if(count==0){
				count=5;
			}
			else{
				count--;
			}
			
		}
		else if(ch==80){
			if(count==5){
				count=0;
			}
			else{
			
				count++;
			}
		}	
	}
	
	if(count==0){
		system("CLS");
		login1();
	}
	else if(count==1){
		system("CLS");
		registration();
	}
	else if(count==2){
		system("CLS");
		login(count);
	}
	else if(count==3){
		system("CLS");
		login(count);
	}
	else if(count==4){
		system("CLS");
		loginAdmin();
	}
	else{
		exit(1);
	}
}
void login1(){
	fflush(stdin);
		system("CLS");
	char userEntered[50];
	char passEntered[50];
	int flag=0;
	int balance;
	char ch;
	int i=0,j;
	int currentBalance;
	printf("\n------------------------Player 1 Login------------------------\n");
	FILE *fp=fopen("data.txt","r");
	struct userInfo user;
	while(1){
		fflush(stdin);
		printf("Enter Username: ");gets(userEntered);fflush(stdin);
		system("CLS");
		printf("Password: ");
	while(1){
		passEntered[i]=getch();
		if(passEntered[i]=='\r'){
			break;
		}
		else if(passEntered[i]=='\b'){
			passEntered[i]='\0';
			system("CLS");printf("Password: ");
			if(i>0){
				i--;
			}
			
			for(j=1;j<=i;j++){
				printf("*");	
			}
		}
		else{
			printf("*");
			i++;
		}
		
	}
	int len;
	len=strlen(passEntered);
	passEntered[len-1]='\0';

		while(fread(&user,sizeof(user),1,fp)>0){
			if(strcmp(user.userName,userEntered)==0 && strcmp(user.password,passEntered)==0){
				flag=1;
				currentBalance=user.balance;
				break;
			}
			
		}
		if(flag==1){
			strcpy(user1,userEntered);
			balance1=currentBalance;
			login2();
			break;
		}
		else{
			printf("\nUserName Or Password Not Matched....\n");
			printf("Press Backspace to Go to Menu or Press any key to continue: ");ch=getch();
			if(ch=='\b'){
				displayMenu();
			}
			else{
				login1();	
			}
			
			break;
		}
		
		
	}
}
void login2(){
	fflush(stdin);
	system("CLS");
	char userEntered[50];
	char passEntered[50];
	int flag=0;
	int balance;
	char ch;
	int i=0,j;
	int currentBalance;
	printf("\n------------------------Player 2 Login------------------------\n");
	FILE *fp=fopen("data.txt","r");
	struct userInfo user;
	while(1){
		fflush(stdin);
		i=0;
		printf("Enter Username: ");gets(userEntered);fflush(stdin);
		system("CLS");
		printf("Password: ");
	while(1){
		passEntered[i]=getch();
		if(passEntered[i]=='\r'){
			break;
		}
		else if(passEntered[i]=='\b'){
			passEntered[i]='\0';
			system("CLS");printf("Password: ");
			if(i>0){
				i--;
			}
			for(j=1;j<=i;j++){
				printf("*");	
			}
		}
		else{
			printf("*");
			i++;
		}
		
	}
	int len;
	len=strlen(passEntered);
	passEntered[len-1]='\0';
		while(fread(&user,sizeof(user),1,fp)>0){
			if(strcmp(user.userName,userEntered)==0 && strcmp(user.password,passEntered)==0){
				
				flag=1;
				currentBalance=user.balance;
				break;
			}
			
		}
		
		if(flag==1){
			strcpy(user2,userEntered);
			balance2=currentBalance;
			if(strcmp(user1,user2)==0){
				printf("\nBoth Users Cannot Be Same....\nPress Any Key to Login\nPress Backspace to Go To Main Menu...");sleep(3);
				ch=getch();
				if(ch=='\b'){
					displayMenu();
				}
				else{
					login2();
				}
				login2();
			}
			gameMenu();
			break;
		}
		else{
			printf("\nUserName Or Password Not Matched....\n");
			printf("Press Backspace to Go to Menu or Press any key to continue: ");ch=getch();
			if(ch=='\b'){
				displayMenu();
			}
			else{
				login2();	
			}
			
			break;
		}
		
		
	}
	
}
void gameMenu(){
	fflush(stdin);
	system("CLS");
	char ch;
	int count=0;
	
	while(ch!='\r' && ch!=77){
		
		if(count==0){
			printf("-----------Game Menu------------\n");
			printf("-> Tic Tac Toe\n");
			printf("   Main Menu\n");
			printf("   Exit\n");
			printf("--------------------------------\n");
		}
		
		if(count==1){
			printf("-----------Game Menu------------\n");
			printf("   Tic Tac Toe\n");
			printf("-> Main Menu\n");
			printf("   Exit\n");
			printf("--------------------------------\n");
		}
		
		
		if(count==2){
			printf("-----------Game Menu------------\n");
			printf("   Tic Tac Toe\n");
			printf("   Quiz Game\n");
			printf("-> Exit\n");
			printf("--------------------------------\n");
		}
		ch=getch();
		system("CLS");
		if(ch==72){
			if(count==0){
				count=4;
			}
			else{
				count--;
			}
			
		}
		else if(ch==80){
			if(count==4){
				count=0;
			}
			else{
			
				count++;
			}
		}	
	}
	
	if(count==0){
		system("CLS");
		ticTacToe();
	}
	else if(count==2){
		system("CLS");
		displayMenu();
	}
	else{
		exit(1);
	}
}
void adminMenu(){
	fflush(stdin);
	system("CLS");
	char ch;
	char ch2,ch1;
	int userFlag=0;
	int bal;
	int count=0;
	char userE[30];
	FILE *fp=fopen("data.txt","r");
	struct userInfo userTemp;
	while(ch!='\r' && ch!=77){
		if(count==0){
			printf("-----------Admin Menu------------\n");
			printf("-> Delete User\n");
			printf("   View Users\n");
			printf("   View History\n");
			printf("   Add Balance to Existing User\n");
			printf("   Remove Balance from Existing User\n");
			printf("   Main Menu\n");
			printf("   Exit\n");
			printf("--------------------------------\n");
		}
		if(count==1){
			printf("-----------Admin Menu------------\n");
			printf("   Delete User\n");
			printf("-> View Users\n");
			printf("   View History\n");
			printf("   Add Balance to Existing User\n");
			printf("   Remove Balance from Existing User\n");
			printf("   Main Menu\n");
			printf("   Exit\n");
			printf("--------------------------------\n");
		}
		if(count==2){
			printf("-----------Admin Menu------------\n");
			printf("   Delete User\n");
			printf("   View Users\n");
			printf("-> View History\n");
			printf("   Add Balance to Existing User\n");
			printf("   Remove Balance from Existing User\n");
			printf("   Main Menu\n");
			printf("   Exit\n");
			printf("--------------------------------\n");
		}
		if(count==3){
			printf("-----------Admin Menu------------\n");
			printf("   Delete User\n");
			printf("   View Users\n");
			printf("   View History\n");
			printf("-> Add Balance to Existing User\n");
			printf("   Remove Balance from Existing User\n");
			printf("   Main Menu\n");
			printf("   Exit\n");
			printf("--------------------------------\n");
		}
		if(count==4){
			printf("-----------Admin Menu------------\n");
			printf("   Delete User\n");
			printf("   View Users\n");
			printf("   View History\n");
			printf("   Add Balance to Existing User\n");
			printf("-> Remove Balance from Existing User\n");
			printf("   Main Menu\n");
			printf("   Exit\n");
			printf("--------------------------------\n");
		}
		if(count==5){
			printf("-----------Admin Menu------------\n");
			printf("   Delete User\n");
			printf("   View Users\n");
			printf("   View History\n");
			printf("   Add Balance to Existing User\n");
			printf("   Remove Balance from Existing User\n");
			printf("-> Main Menu\n");
			printf("   Exit\n");
			printf("--------------------------------\n");
		}
		if(count==6){
			printf("-----------Admin Menu------------\n");
			printf("   Delete User\n");
			printf("   View Users\n");
			printf("   View History\n");
			printf("   Add Balance to Existing User\n");
			printf("   Remove Balance from Existing User\n");
			printf("   Main Menu\n");
			printf("-> Exit\n");
			printf("--------------------------------\n");
		}
		ch=getch();
		system("CLS");
		if(ch==72){
			if(count==0){
				count=6;
			}
			else{
				count--;
			}
		}
		else if(ch==80){
			if(count==6){
				count=0;
			}
			else{
			
				count++;
			}
		}	
	}
	if(count==0){
		system("CLS");
		fflush(stdin);
		while(1){
		printf("\nEnter UserName To Delete: ");gets(userE);
		fp=fopen("data.txt","r");
		while(fread(&userTemp,sizeof(userTemp),1,fp)>0){
			if(strcmp(userE,userTemp.userName)==0){
				userFlag=1;
				break;
			}
		}
		if(userFlag==1){
			deleteUser(userE);
			break;
		}
		else{
			printf("\nUsername Not found...\n");
			printf("Press Backspace to Go to Admin or Press any key to continue: ");ch1=getch();
					if(ch1=='\b'){
						adminMenu();
						break;
					}
					else{
						system("CLS");
						fflush(stdin);
					}
			}
		}
	}
	else if(count==1){
		system("CLS");
		viewUsers();
		printf("\nEnter Any Key to Go Back To Admin Menu...\n");
		ch2=getch();
		adminMenu();
	}
	else if(count==2){
		system("CLS");
		viewHistory();
		printf("\nEnter Any Key to Go Back to Admin Menu...\n");
		ch2=getch();
		adminMenu();
	}
	else if(count==3){
		system("CLS");
		fflush(stdin);
		while(1){
		printf("\nEnter UserName to Add Funds To: ");gets(userE);fflush(stdin);
		fp=fopen("data.txt","r");
		while(fread(&userTemp,sizeof(userTemp),1,fp)>0){
			if(strcmp(userE,userTemp.userName)==0){
				userFlag=1;
				break;
			}
		}
		if(userFlag==1){
			break;
		}
		else{
			printf("\nUsername Not found...\n");
			printf("Press Backspace to Go to Admin or Press any key to continue: ");ch1=getch();
					if(ch1=='\b'){
						adminMenu();
						break;
					}
					else{
						system("CLS");
						fflush(stdin);
					}
		}}
		printf("\nCurrent Balance: %d",currentBalance(userE));
		while(1){
		printf("\nEnter total balance to Add to the account: ");scanf("%d",&bal);
		if(bal<0){
			printf("\nBalance to be added cannot be negative...\n");
			printf("Press Backspace to Go to Admin or Press any key to continue: ");ch1=getch();
					if(ch1=='\b'){
						adminMenu();
						break;
					}
					else{
						
					}
		}
		else if(bal>=0 && bal<=100000){
			break;
		}
		else{
			printf("\nInvalid Balance...\n");
			printf("Press Backspace to Go to Admin or Press any key to continue: ");ch1=getch();
					if(ch1=='\b'){
						adminMenu();
						break;
					}
					else{
						
					}
		}
	}
		addFund(userE,bal);
		printf("\nNew Balance is %d",currentBalance(userE));
		sleep(2);
		adminMenu();
	}
	else if(count==4){
		system("CLS");
		fflush(stdin);
		while(1){
		printf("\nEnter UserName to Remove Funds From: ");gets(userE);fflush(stdin);
		fp=fopen("data.txt","r");
		while(fread(&userTemp,sizeof(userTemp),1,fp)>0){
			if(strcmp(userE,userTemp.userName)==0){
				userFlag=1;
				break;
			}
		}
		if(userFlag==1){
			break;
		}
		else{
			printf("\nUsername Not found...\n");
			printf("Press Backspace to Go to Admin or Press any key to continue: ");ch1=getch();
					if(ch1=='\b'){
						adminMenu();
						break;
					}
					else{
						system("CLS");
						fflush(stdin);
					}
		}}
		printf("\nCurrent Balance: %d",currentBalance(userE));
		while(1){
		printf("\nEnter total balance to Remove from the account: ");scanf("%d",&bal);
		if(bal<0){
			printf("\nBalance to be removed cannot be negative...\n");
			printf("Press Backspace to Go to Admin or Press any key to continue: ");ch1=getch();
					if(ch1=='\b'){
						adminMenu();
						break;
					}
					else{
					}
		}
		
		else{
			break;
		}
	}
		removeFund(userE,bal);
		printf("\nNew Balance is %d",currentBalance(userE));
		sleep(2);
		adminMenu();
	}
	else if(count==5){
		displayMenu();
	}
	else{
		exit(1);
	}
}
void loginAdmin(){
	fflush(stdin);
	system("CLS");
	char passEntered[30];
	char ch;
	int i=0,j;
	int len;
	int bflag=0;
	printf("\n------------------------Admin Login------------------------\n");
	adminMenu();		
}
void deleteUser(char userN[30]){
	fflush(stdin);
	FILE *fp=fopen("data.txt","r");
	FILE *tempF=fopen("temp.txt","w");
	tempF=fopen("temp.txt","a");
	struct userInfo user;
	while(fread(&user,sizeof(user),1,fp)>0){
		if(strcmp(userN,user.userName)==0){
			printf("\nUser Deleted....\n");
			sleep(2);
		}
		else{
			fwrite(&user,sizeof(user),1,tempF);
		}
		
	}
	fclose(tempF);
	fclose(fp);
	FILE *fp1=fopen("data.txt","w");
	fclose(fp1);
	FILE *fpM=fopen("data.txt","a");
	FILE *fpT=fopen("temp.txt","r");
	while(fread(&user,sizeof(user),1,fpT)>0){
		fwrite(&user,sizeof(user),1,fpM);
	}
	fclose(fpM);
	fclose(fpT);
	adminMenu();
}
void viewUsers(){
	fflush(stdin);
	struct userInfo user;
	FILE *fp=fopen("data.txt","r");
	while(fread(&user,sizeof(user),1,fp)>0){
		displayInfo(user.userName);
		printf("\n\n");
	}
}
void viewHistory(){
	fflush(stdin);
	system("CLS");
	char ch;
	int count=0;
	FILE *fp=fopen("history.txt","r");
	while(!feof(fp)){
		ch=fgetc(fp);
		printf("%c",ch);
	}
	
}
